"""
Модуль bot.utils.logger удалён.
Импортируйте:
  - setup_logging из bot.services.logging_setup
  - log_action   из bot.services.actions
"""
raise ImportError("bot.utils.logger удалён. Используйте bot.services.logging_setup.setup_logging и bot.services.actions.log_action")
